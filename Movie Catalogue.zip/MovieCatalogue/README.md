"# MovieCatalogue" 
Submission Part 1 Dicoding
