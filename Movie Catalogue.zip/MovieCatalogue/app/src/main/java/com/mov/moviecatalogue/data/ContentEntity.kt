package com.mov.moviecatalogue.data

data class ContentEntity(
        var content: String?
)