package com.mov.moviecatalogue.data

data class TvShowEntity (
        var movieId: String,
        var title: String,
        var genre: String,
        var headline: String,
        var overview: String,
        var imagePath: String
)