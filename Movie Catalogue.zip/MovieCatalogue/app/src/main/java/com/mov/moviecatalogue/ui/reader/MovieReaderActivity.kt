package com.mov.moviecatalogue.ui.reader

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mov.moviecatalogue.R

class MovieReaderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_reader)
    }
}